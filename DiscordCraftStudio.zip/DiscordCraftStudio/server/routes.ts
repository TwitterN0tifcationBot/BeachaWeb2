import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { botSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Bot management routes
  app.get("/api/bots", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const bots = await storage.getBots(req.user.id);
    res.json(bots);
  });

  app.post("/api/bots", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const validation = botSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json(validation.error);
    }
    
    try {
      const bot = await storage.createBot({
        ...req.body,
        userId: req.user.id,
      });
      res.status(201).json(bot);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/bots/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const bot = await storage.getBot(parseInt(req.params.id));
    if (!bot) return res.sendStatus(404);
    if (bot.userId !== req.user.id) return res.sendStatus(403);
    
    res.json(bot);
  });

  app.patch("/api/bots/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const bot = await storage.getBot(parseInt(req.params.id));
    if (!bot) return res.sendStatus(404);
    if (bot.userId !== req.user.id) return res.sendStatus(403);

    const validation = botSchema.partial().safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json(validation.error);
    }

    const updated = await storage.updateBot(parseInt(req.params.id), req.body);
    res.json(updated);
  });

  app.delete("/api/bots/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const bot = await storage.getBot(parseInt(req.params.id));
    if (!bot) return res.sendStatus(404);
    if (bot.userId !== req.user.id) return res.sendStatus(403);

    await storage.deleteBot(parseInt(req.params.id));
    res.sendStatus(204);
  });

  const httpServer = createServer(app);
  return httpServer;
}
