import { InsertUser, User, Bot, insertBotSchema } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

declare module "express-session" {
  interface SessionData {
    passport: { user: number };
  }
}

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getBots(userId: number): Promise<Bot[]>;
  getBot(id: number): Promise<Bot | undefined>;
  createBot(bot: Bot): Promise<Bot>;
  updateBot(id: number, bot: Partial<Bot>): Promise<Bot>;
  deleteBot(id: number): Promise<void>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private bots: Map<number, Bot>;
  private currentUserId: number;
  private currentBotId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.bots = new Map();
    this.currentUserId = 1;
    this.currentBotId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getBots(userId: number): Promise<Bot[]> {
    return Array.from(this.bots.values()).filter(bot => bot.userId === userId);
  }

  async getBot(id: number): Promise<Bot | undefined> {
    return this.bots.get(id);
  }

  async createBot(bot: Bot): Promise<Bot> {
    const userBots = await this.getBots(bot.userId);
    if (userBots.length >= 5) {
      throw new Error("Bot limit reached (max 5)");
    }
    
    const id = this.currentBotId++;
    const newBot = { ...bot, id };
    this.bots.set(id, newBot);
    return newBot;
  }

  async updateBot(id: number, bot: Partial<Bot>): Promise<Bot> {
    const existing = await this.getBot(id);
    if (!existing) throw new Error("Bot not found");
    
    const updated = { ...existing, ...bot };
    this.bots.set(id, updated);
    return updated;
  }

  async deleteBot(id: number): Promise<void> {
    this.bots.delete(id);
  }
}

export const storage = new MemStorage();