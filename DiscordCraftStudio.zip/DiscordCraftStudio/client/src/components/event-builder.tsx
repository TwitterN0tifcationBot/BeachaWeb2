import { Event, eventSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

interface EventBuilderProps {
  event?: Event;
  onSave: (event: Event) => void;
  onCancel: () => void;
}

const eventTypes = [
  "messageCreate",
  "guildMemberAdd",
  "guildMemberRemove",
  "channelCreate",
  "channelDelete",
  "roleCreate",
  "roleDelete",
  "interactionCreate",
  "ready",
  "error",
];

export default function EventBuilder({ event, onSave, onCancel }: EventBuilderProps) {
  const form = useForm<Event>({
    resolver: zodResolver(eventSchema),
    defaultValues: event || {
      name: "",
      description: "",
      handler: "",
    },
  });

  return (
    <form onSubmit={form.handleSubmit(onSave)} className="space-y-6">
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Event Name</Label>
          <select
            {...form.register("name")}
            className="w-full rounded-md border border-input bg-transparent px-3 py-2"
          >
            <option value="">Select an event</option>
            {eventTypes.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
          {form.formState.errors.name && (
            <p className="text-sm text-destructive">
              {form.formState.errors.name.message}
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label>Description</Label>
          <Input
            {...form.register("description")}
            placeholder="What should this event do?"
            error={form.formState.errors.description?.message}
          />
        </div>

        <div className="space-y-2">
          <Label>Handler Code</Label>
          <Textarea
            {...form.register("handler")}
            placeholder="Event handler code..."
            className="font-mono"
            rows={8}
            error={form.formState.errors.handler?.message}
          />
        </div>
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">Save Event</Button>
      </div>
    </form>
  );
}
