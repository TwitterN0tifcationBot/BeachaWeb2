import { Command, commandSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Plus, Minus } from "lucide-react";
import { useFieldArray, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

interface CommandBuilderProps {
  command?: Command;
  onSave: (command: Command) => void;
  onCancel: () => void;
}

const optionTypes = [
  { value: "STRING", label: "Text" },
  { value: "INTEGER", label: "Number" },
  { value: "BOOLEAN", label: "Yes/No" },
  { value: "USER", label: "User" },
  { value: "CHANNEL", label: "Channel" },
];

export default function CommandBuilder({ command, onSave, onCancel }: CommandBuilderProps) {
  const form = useForm<Command>({
    resolver: zodResolver(commandSchema),
    defaultValues: command || {
      name: "",
      description: "",
      options: [],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "options",
  });

  return (
    <form onSubmit={form.handleSubmit(onSave)} className="space-y-6">
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Command Name</Label>
          <Input
            {...form.register("name")}
            placeholder="e.g., ping"
            error={form.formState.errors.name?.message}
          />
        </div>

        <div className="space-y-2">
          <Label>Description</Label>
          <Input
            {...form.register("description")}
            placeholder="What does this command do?"
            error={form.formState.errors.description?.message}
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Command Options</Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() =>
                append({
                  name: "",
                  description: "",
                  type: "STRING",
                  required: false,
                })
              }
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Option
            </Button>
          </div>

          {fields.map((field, index) => (
            <div key={field.id} className="space-y-4 p-4 border rounded-lg">
              <div className="flex justify-between items-start">
                <h4 className="font-medium">Option {index + 1}</h4>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => remove(index)}
                >
                  <Minus className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Name</Label>
                    <Input
                      {...form.register(`options.${index}.name`)}
                      placeholder="Option name"
                      error={form.formState.errors.options?.[index]?.name?.message}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Type</Label>
                    <Select
                      onValueChange={(value) =>
                        form.setValue(`options.${index}.type`, value as any)
                      }
                      defaultValue={field.type}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {optionTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Description</Label>
                  <Input
                    {...form.register(`options.${index}.description`)}
                    placeholder="What is this option for?"
                    error={
                      form.formState.errors.options?.[index]?.description?.message
                    }
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    {...form.register(`options.${index}.required`)}
                    defaultChecked={field.required}
                  />
                  <Label>Required</Label>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">Save Command</Button>
      </div>
    </form>
  );
}
