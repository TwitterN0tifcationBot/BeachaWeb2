import { useQuery } from "@tanstack/react-query";
import { Bot } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Plus, Bot as BotIcon, Loader2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();

  const { data: bots, isLoading } = useQuery<Bot[]>({
    queryKey: ["/api/bots"],
  });

  const deleteBot = async (id: number) => {
    try {
      await apiRequest("DELETE", `/api/bots/${id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      toast({
        title: "Bot deleted",
        description: "The bot has been successfully deleted.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete the bot.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <BotIcon className="h-6 w-6" />
            <h1 className="text-2xl font-bold">B9</h1>
          </div>
          <div className="flex items-center gap-4">
            <span>Welcome, {user?.username}</span>
            <Button variant="outline" onClick={() => logoutMutation.mutate()}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold mb-2">Your Bots</h2>
            <p className="text-muted-foreground">
              Create and manage your Discord bots
            </p>
          </div>
          {(!bots || bots.length < 5) && (
            <Link href="/bots/new">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Bot
              </Button>
            </Link>
          )}
        </div>

        {bots && bots.length > 0 ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {bots.map((bot) => (
              <Card key={bot.id}>
                <CardHeader>
                  <CardTitle>{bot.name}</CardTitle>
                  <CardDescription>
                    {bot.commands.length} commands • {bot.events.length} events
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div>
                      <span className="text-sm font-medium">Commands:</span>
                      <span className="text-sm text-muted-foreground ml-2">
                        {bot.commands.length}/25
                      </span>
                    </div>
                    <div>
                      <span className="text-sm font-medium">Events:</span>
                      <span className="text-sm text-muted-foreground ml-2">
                        {bot.events.length}/10
                      </span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Link href={`/bots/${bot.id}`}>
                    <Button variant="outline">Edit Bot</Button>
                  </Link>
                  <Button
                    variant="destructive"
                    size="icon"
                    onClick={() => deleteBot(bot.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-12">
            <CardContent>
              <div className="flex flex-col items-center gap-4">
                <BotIcon className="h-12 w-12 text-muted-foreground" />
                <div>
                  <h3 className="text-lg font-medium">No bots yet</h3>
                  <p className="text-sm text-muted-foreground">
                    Create your first Discord bot to get started
                  </p>
                </div>
                <Link href="/bots/new">
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Bot
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
