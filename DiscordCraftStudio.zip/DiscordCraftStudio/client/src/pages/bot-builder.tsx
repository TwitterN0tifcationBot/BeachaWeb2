import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Bot, Command, Event, botSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import CommandBuilder from "@/components/command-builder";
import EventBuilder from "@/components/event-builder";
import { Plus, ArrowLeft, Trash2, Sparkles } from "lucide-react";
import { z } from "zod";

const templates = {
  custom: {
    name: "Custom Bot",
    description: "Start from scratch and build your own bot",
    commands: [],
    events: [],
  },
  moderation: {
    name: "Moderation Bot",
    description: "A bot with basic moderation commands",
    commands: [
      {
        name: "kick",
        description: "Kick a user from the server",
        options: [
          {
            name: "user",
            description: "The user to kick",
            type: "USER",
            required: true,
          },
          {
            name: "reason",
            description: "Reason for kicking",
            type: "STRING",
            required: false,
          },
        ],
      },
      {
        name: "ban",
        description: "Ban a user from the server",
        options: [
          {
            name: "user",
            description: "The user to ban",
            type: "USER",
            required: true,
          },
          {
            name: "reason",
            description: "Reason for banning",
            type: "STRING",
            required: false,
          },
        ],
      },
    ],
    events: [
      {
        name: "messageCreate",
        description: "Auto-moderate messages",
        handler: "// Auto-moderation logic here",
      },
    ],
  },
  giveaway: {
    name: "Giveaway Bot",
    description: "A bot for running server giveaways",
    commands: [
      {
        name: "gstart",
        description: "Start a giveaway",
        options: [
          {
            name: "prize",
            description: "What to give away",
            type: "STRING",
            required: true,
          },
          {
            name: "winners",
            description: "Number of winners",
            type: "INTEGER",
            required: true,
          },
          {
            name: "duration",
            description: "Duration in minutes",
            type: "INTEGER",
            required: true,
          },
        ],
      },
      {
        name: "gend",
        description: "End a giveaway",
        options: [
          {
            name: "message",
            description: "Giveaway message ID",
            type: "STRING",
            required: true,
          },
        ],
      },
    ],
    events: [],
  },
  leveling: {
    name: "Leveling Bot",
    description: "A bot for tracking user activity and levels",
    commands: [
      {
        name: "rank",
        description: "Check your rank",
        options: [
          {
            name: "user",
            description: "User to check (optional)",
            type: "USER",
            required: false,
          },
        ],
      },
      {
        name: "leaderboard",
        description: "Show server leaderboard",
        options: [],
      },
    ],
    events: [
      {
        name: "messageCreate",
        description: "Track user activity",
        handler: "// XP calculation logic here",
      },
    ],
  },
};

export default function BotBuilder() {
  const [, setLocation] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const [commandDialog, setCommandDialog] = useState(false);
  const [eventDialog, setEventDialog] = useState(false);
  const [selectedCommand, setSelectedCommand] = useState<Command | undefined>();
  const [selectedEvent, setSelectedEvent] = useState<Event | undefined>();
  const [botName, setBotName] = useState("");
  const [botToken, setBotToken] = useState("");

  const { data: bot, isLoading } = useQuery<Bot>({
    queryKey: ["/api/bots", id],
    enabled: !!id,
  });

  const createBot = useMutation({
    mutationFn: async (bot: Partial<Bot>) => {
      const res = await apiRequest("POST", "/api/bots", bot);
      return res.json();
    },
    onSuccess: () => {
      setLocation("/");
      toast({
        title: "Success",
        description: "Bot created successfully",
      });
    },
  });

  const updateBot = useMutation({
    mutationFn: async (bot: Partial<Bot>) => {
      const res = await apiRequest("PATCH", `/api/bots/${id}`, bot);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots", id] });
      toast({
        title: "Success",
        description: "Bot updated successfully",
      });
    },
  });

  const handleSaveCommand = (command: Command) => {
    if (!bot) return;

    const botCommands = (bot.commands as Command[]) || [];
    const commands = [...botCommands];
    if (selectedCommand) {
      const index = commands.findIndex((c) => c.name === selectedCommand.name);
      commands[index] = command;
    } else {
      if (commands.length >= 25) {
        toast({
          title: "Error",
          description: "Maximum command limit reached (25)",
          variant: "destructive",
        });
        return;
      }
      commands.push(command);
    }

    updateBot.mutate({ commands });
    setCommandDialog(false);
    setSelectedCommand(undefined);
  };

  const handleSaveEvent = (event: Event) => {
    if (!bot) return;

    const botEvents = (bot.events as Event[]) || [];
    const events = [...botEvents];
    if (selectedEvent) {
      const index = events.findIndex((e) => e.name === selectedEvent.name);
      events[index] = event;
    } else {
      if (events.length >= 10) {
        toast({
          title: "Error",
          description: "Maximum event limit reached (10)",
          variant: "destructive",
        });
        return;
      }
      events.push(event);
    }

    updateBot.mutate({ events });
    setEventDialog(false);
    setSelectedEvent(undefined);
  };

  const applyTemplate = (template: keyof typeof templates) => {
    const { name, commands, events } = templates[template];
    if (id) {
      updateBot.mutate({ name, commands, events });
    } else {
      if (template === 'custom') {
        // For custom bots, only create when name and token are provided
        if (!botName || !botToken) {
          toast({
            title: "Error",
            description: "Please provide a name and token for your bot",
            variant: "destructive",
          });
          return;
        }
        createBot.mutate({ name: botName, token: botToken, commands: [], events: [] });
      } else {
        createBot.mutate({ name, token: '', commands, events });
      }
    }
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            className="mb-4"
            onClick={() => setLocation("/")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Bots
          </Button>
          <h1 className="text-2xl font-bold">
            {id ? "Edit Bot" : "Create New Bot"}
          </h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue={id ? "builder" : "templates"}>
          <TabsList>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="builder">Bot Builder</TabsTrigger>
          </TabsList>

          <TabsContent value="templates" className="space-y-6">
            {!id && (
              <div className="border rounded-lg p-6 mb-8">
                <h3 className="text-lg font-medium mb-4">Create Custom Bot</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Bot Name</Label>
                    <Input
                      value={botName}
                      onChange={(e) => setBotName(e.target.value)}
                      placeholder="Enter your bot's name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Bot Token</Label>
                    <Input
                      type="password"
                      value={botToken}
                      onChange={(e) => setBotToken(e.target.value)}
                      placeholder="Enter your Discord bot token"
                    />
                  </div>
                </div>
                <Button
                  className="mt-4"
                  onClick={() => applyTemplate('custom')}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Custom Bot
                </Button>
              </div>
            )}

            <div className="grid gap-6 md:grid-cols-2">
              {Object.entries(templates).filter(([key]) => key !== 'custom').map(([key, template]) => (
                <div key={key} className="border rounded-lg p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    <h3 className="text-lg font-medium">{template.name}</h3>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    {template.description}
                  </p>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                    <span>{template.commands.length} commands</span>
                    <span>•</span>
                    <span>{template.events.length} events</span>
                  </div>
                  <Button onClick={() => applyTemplate(key as keyof typeof templates)}>
                    Use Template
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="builder" className="space-y-8">
            {bot && (
              <>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <Label>Commands ({bot.commands.length}/25)</Label>
                    <div className="space-y-2 mt-2">
                      {bot.commands && (bot.commands as Command[]).map((command) => (
                        <div
                          key={command.name}
                          className="flex items-center justify-between p-3 border rounded-lg"
                        >
                          <div>
                            <h4 className="font-medium">/{command.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {command.description}
                            </p>
                          </div>
                          <div className="flex space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedCommand(command);
                                setCommandDialog(true);
                              }}
                            >
                              Edit
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() =>
                                updateBot.mutate({
                                  commands: (bot.commands as Command[]).filter(
                                    (c) => c.name !== command.name
                                  ),
                                })
                              }
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                      {bot.commands && (bot.commands as Command[]).length < 25 && (
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => setCommandDialog(true)}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Command
                        </Button>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label>Events ({bot.events.length}/10)</Label>
                    <div className="space-y-2 mt-2">
                      {bot.events && (bot.events as Event[]).map((event) => (
                        <div
                          key={event.name}
                          className="flex items-center justify-between p-3 border rounded-lg"
                        >
                          <div>
                            <h4 className="font-medium">{event.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {event.description}
                            </p>
                          </div>
                          <div className="flex space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedEvent(event);
                                setEventDialog(true);
                              }}
                            >
                              Edit
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() =>
                                updateBot.mutate({
                                  events: (bot.events as Event[]).filter(
                                    (e) => e.name !== event.name
                                  ),
                                })
                              }
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                      {bot.events && (bot.events as Event[]).length < 10 && (
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => setEventDialog(true)}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Event
                        </Button>
                      )}
                    </div>
                  </div>
                </div>

                <Dialog open={commandDialog} onOpenChange={setCommandDialog}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>
                        {selectedCommand ? "Edit Command" : "Add Command"}
                      </DialogTitle>
                    </DialogHeader>
                    <CommandBuilder
                      command={selectedCommand}
                      onSave={handleSaveCommand}
                      onCancel={() => {
                        setCommandDialog(false);
                        setSelectedCommand(undefined);
                      }}
                    />
                  </DialogContent>
                </Dialog>

                <Dialog open={eventDialog} onOpenChange={setEventDialog}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>
                        {selectedEvent ? "Edit Event" : "Add Event"}
                      </DialogTitle>
                    </DialogHeader>
                    <EventBuilder
                      event={selectedEvent}
                      onSave={handleSaveEvent}
                      onCancel={() => {
                        setEventDialog(false);
                        setSelectedEvent(undefined);
                      }}
                    />
                  </DialogContent>
                </Dialog>
              </>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}