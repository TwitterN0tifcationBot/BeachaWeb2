import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const bots = pgTable("bots", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  token: text("token").notNull(),
  commands: jsonb("commands").notNull().default([]),
  events: jsonb("events").notNull().default([]),
});

export const commandSchema = z.object({
  name: z.string(),
  description: z.string(),
  options: z.array(z.object({
    name: z.string(),
    description: z.string(),
    type: z.enum(["STRING", "INTEGER", "BOOLEAN", "USER", "CHANNEL"]),
    required: z.boolean()
  })).default([])
});

export const eventSchema = z.object({
  name: z.string(),
  description: z.string(),
  handler: z.string()
});

export const botSchema = z.object({
  name: z.string(),
  token: z.string(),
  commands: z.array(commandSchema).max(25),
  events: z.array(eventSchema).max(10)
});

export const insertUserSchema = createInsertSchema(users);
export const insertBotSchema = createInsertSchema(bots);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Bot = typeof bots.$inferSelect;
export type Command = z.infer<typeof commandSchema>;
export type Event = z.infer<typeof eventSchema>;
